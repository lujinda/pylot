#coding:utf8
import re
import web
from config import render,db

class sendSubmit:
    def POST(self):
        data=web.input()  # post的数据
        if not self.check(data.Phone,r"^\d{6}$|^\d{11}$"):
            return render.frame.main("请填写正确的号码（短号或长号）")   

        if len(data.Name)>15:
            return render.frame.main("亲，您的名字有这么长吗？")
            
        if len(data.Content)<10:
            return render.frame.main("亲，故障请写得稍微详细点哦～")
        
        try:
            self.writeDb(data)
            return render.frame.main("您的故障情况，我会已收到<br>我们会尽快联系您")
        except:
            return render.frame.main("提交失败")

    def writeDb(self,data):
        import time
        db.insert("bugs",Content=data.Content,Name=data.Name,
                Phone=data.Phone,Room=data.Room,
                PostTime=time.strftime("%Y-%m-%d %H:%M:%S",time.localtime()),
                IsOver=0,
                Time=data.Time,
                )
        
    def check(self,data,r):
        if re.match(r,data):
            return True
        else:
            return False
        
